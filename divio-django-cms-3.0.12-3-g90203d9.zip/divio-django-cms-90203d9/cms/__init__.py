# -*- coding: utf-8 -*-
__version__ = '3.0.12.post0'

default_app_config = 'cms.apps.CMSConfig'
