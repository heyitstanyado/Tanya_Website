# -*- coding: utf-8 -*-
from django.utils.translation import ugettext_lazy as _
TEMPLATES = {
    'wrong_col_two.html': _('Two columns'),
    'wrong_col_three.html': _('Three columns'),
}